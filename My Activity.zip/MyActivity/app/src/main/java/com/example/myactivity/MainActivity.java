package com.example.myactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnDownload;
    ProgressBar pbLoading;
    TextView tvStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindView();
        btnDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DownloadImageAsync downloadImageAsync = new DownloadImageAsync(MainActivity.this,pbLoading, tvStatus);
                downloadImageAsync.execute();
            }
        });
    }

    private void bindView(){
        btnDownload = findViewById(R.id.btnDownload);
        pbLoading = findViewById(R.id.pbLoading);
        tvStatus = findViewById(R.id.tvStatus);
    }
}
