package com.example.myactivity;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ProgressBar;
import android.widget.TextView;

public class DownloadImageAsync extends AsyncTask<String, Integer, String> {
    private Context context;
    private ProgressBar progressBar;
    private TextView tvStatus;

    public DownloadImageAsync(Context context, ProgressBar progressBar, TextView tvStatus) {
        this.context = context;
        this.progressBar = progressBar;
        this.tvStatus = tvStatus;
    }

    @Override
    protected String doInBackground(String... strings) {
        for ( int i = 0 ; i<100; i++){
            publishProgress(i);
        }
        return "Download Complete";
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        tvStatus.setText("Downloading ...");
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        tvStatus.setText(s);
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        int prograss = values[0];
        progressBar.setProgress(prograss);
        super.onProgressUpdate(values);
    }


}
